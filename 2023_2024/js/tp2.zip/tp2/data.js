"use strict";

let tableau1 = [2, 5, 45, 1, 7, 9];
let tableau2 = [6, 2, 23, 9, 45, 1, 11, 5, 7, 12];
let tableau3 = [6, 2, 23, 9, 45, 1, 11, 7, 12];

let chaine1 = "Lorem Ipsum is simply dummy text of the printing printer book and typesetting industry. Lorem Ipsum has been tprinterhe industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, book but also the leap into electronic typesetting, remaining essentially printer unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publprinterishing software like Aldus PageprinterMaker including versions book of Lorem Ipsum.";

let trinome1 = { 'a': 5, 'b': 2, 'c': -6};
let trinome2 = { 'a': 5, 'c': -6};
let trinome3 = { 'toto': 'test', 'a': 5, 'b': 13, 'c': -6};
let trinome4 = { 'a': 3, 'b': 2, 'c': 5};


let liste = {
    "Cole": {
        "nom": "Cole",
        "prenom": "Hickman",
        "email": "marquitatillman@sarasonic.com",
        "telephone": "06.31.17.18.12"
    },
    "Triat": {
        "nom": "Triat",
        "prenom": "Welch",
        "telephone": "06.96.93.50.31"
    },
    "Cabrera": {
        "nom": "Cabrera",
        "prenom": "Gay",
        "email": "hopkinslarson@netur.com"
    },
    "Humphrey": {
        "nom": "Humphrey",
        "prenom": "Jody"
    }
};