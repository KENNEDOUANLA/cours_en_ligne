"use strict";

const categories = [
    {
        "categorie": "Entrées et plats composés",
        "id": "cat_2487"
    },
    {
        "categorie": "Fruits, légumes, légumineuses et oléagineux",
        "id": "cat_9412"
    },
    {
        "categorie": "Produits céréaliers",
        "id": "cat_6591"
    },
    {
        "categorie": "Viandes, œufs, poissons et assimilés",
        "id": "cat_3611"
    },
    {
        "categorie": "Produits laitiers et assimilés",
        "id": "cat_7003"
    },
    {
        "categorie": "Eaux et autres boissons",
        "id": "cat_6449"
    },
    {
        "categorie": "Produits sucrés",
        "id": "cat_5315"
    },
    {
        "categorie": "Glaces et sorbets",
        "id": "cat_2538"
    },
    {
        "categorie": "Matières grasses",
        "id": "cat_9076"
    },
    {
        "categorie": "Aides culinaires et ingrédients divers",
        "id": "cat_6210"
    }
]