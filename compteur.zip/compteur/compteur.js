"use strict";
let listeIngredients = [];
function makeSelectIngredients(event)
{
    
    const id_categorie = event.target.dataset.categorieId;
    const select = document.getElementById("select-ingredients");
    select.innerHTML='';
    let base_option = document.createElement("option")
    base_option.textContent = "Sélectionner un ingrédient/plat"
    select.appendChild(base_option)
    ingredients.filter(ingredient =>
        ingredient.categorie == id_categorie).forEach(item =>{
            var option = document.createElement("option");
            option.value = item.id;
            option.textContent = item.ingredient;
            select.appendChild(option);
    });
}   

function afficheCategories()
{
    const wrapper = document.getElementById("categories-items")
    categories.forEach(item =>
    {
        var li = document.createElement('li');
        li.innerHTML = item.categorie;
        li.dataset.categorieId = item.id;
        li.classList.add('categorie');
        li.addEventListener('click',makeSelectIngredients)
        wrapper.appendChild(li);
    });
}
const tbody = document.getElementsByTagName('tbody');
const tfoot = document.getElementsByTagName('tfoot');
function ajouterIngredient(e)
{
    table.classList.remove('table-hide');
    e.preventDefault()
    const formchildren = e.target;
    const item = formchildren[2].value;
    const poids = formchildren[3].value;
    listeIngredients.push({ item, poids }) 
    afficheRepas(listeIngredients);
}
async function  afficheRepas(liste)
{
    tbody[0].innerHTML = '';
    const total = [false,false,0,0,0,0,0]
    
    liste.forEach(element =>
    {
        const repas = ingredients.find(ingre => ingre.id == element.item);
        if (repas) {
            total[2] = total[2] + repas.energie;
            total[3] = total[3] + repas.proteines;
            total[4] = total[4] + repas.lipides;
            total[5] = total[5] + repas.glucides;
            total[6] = total[6] + repas.sucres;
            tbody[0].appendChild(addLigne(repas, element.poids)); 
        }
    })
    const tfooter =tfoot[0].getElementsByTagName('th');
    for (let index = 2; index <tfooter.length; index++) {
        tfooter[index].innerText = total[index];
        
    }
}    

function addLigne(ingredient,poids)
{
    var tr = document.createElement("tr");
    var td1 = document.createElement("td");
    td1.innerText = ingredient.ingredient;
    var td2 = document.createElement("td");
    td2.innerText = poids + 'g';
    var td3 = document.createElement("td");
    td3.innerText = ingredient.energie;
    var td4 = document.createElement("td");
    td4.innerText = ingredient.proteines;
    var td5 = document.createElement("td");
    td5.innerText = ingredient.lipides;
    var td6 = document.createElement("td");
    td6.innerText = ingredient.glucides;
    var td7 = document.createElement("td");
    td7.innerText =ingredient.sucres
    tr.append(td1, td2, td3, td4, td5, td6, td7);
    return tr;
}
function raz()
{
    listeIngredients = [];
    tbody[0].innerHTML = '';
    const select = document.getElementById("select-ingredients");
    select.innerHTML='';
    let base_option = document.createElement("option")
    base_option.textContent = "Sélectionner un ingrédient/plat"
    select.appendChild(base_option)
    const tfooter =tfoot[0].getElementsByTagName('th');
    for (let index = 2; index <tfooter.length; index++) {
        tfooter[index].innerText = '';
    }
    const table = document.getElementById("table");
    table.classList.add('table-hide');
}
function init() {
    // initialisation
    afficheCategories()
    let Add = document.getElementById("selection");
    Add.addEventListener("submit", ajouterIngredient)
    let Reset = document.getElementById('reset');
    Reset.addEventListener('click',raz)
}
