"use strict";

let tableau1 = [2, 5, 9, 45, 1, 5, 7, 9];
let tableau2 = [9, 12, 4, 78, 0, 45, 2, 10, 29];

let chaine1 = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";

let message1 = "lI tuaf reuqramer euq egadocne'l te el egadocéd tse tiaf ceva tnemetcaxe el emêm edoc";

let message2 = "uk dnyr nkkze xibqykrze qib iogrnkli";



let liste = {
    "Cole": {
        "nom": "Cole",
        "prenom": "Hickman",
        "email": "marquitatillman@sarasonic.com",
        "telephone": "06.31.17.18.12"
    },
    "Triat": {
        "nom": "Triat",
        "prenom": "Welch",
        "telephone": "06.96.93.50.31"
    },
    "Cabrera": {
        "nom": "Cabrera",
        "prenom": "Gay",
        "email": "hopkinslarson@netur.com"
    },
    "Humphrey": {
        "nom": "Humphrey",
        "prenom": "Jody"
    }
};