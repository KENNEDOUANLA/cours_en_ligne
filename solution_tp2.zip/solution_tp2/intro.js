"use strict";
"use strict";
const tableauMois = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
const tableauJours = ['dimanche','lundi','mardi','mercredi','jeudi','vendredi','samedi'];
const clavier=['a','z','e','r','t','y','u','i','o','p','q','s','d','f','g','h','j','k','l','m','w','x','c','v','b','n']


// Fonctions
function hello(name)
{
    return "Hello " + name;
}
const bey = (name) =>
{
    return `Goodbye ${name}`;
}

console.log(hello("Dolly"));
console.log(bey("Mike"));
console.log('------------------------------');

// Tableaux
const sommeTableau = (tab) =>
{
    let total = 0;
    tab.forEach(element => {
        total += element;
    });
    return total;
}

const derniers = (tab,n) =>
{
    if (n > tab.length)
        return tab;
    else
        return tab.slice(-n);
}

const plusGrands = (tab, n) =>
{
    return tab.filter(element => element > n);
}

const elementsCommuns = (tab1, tab2) =>
{
    const sortie = [];
    tab1.forEach(element => {
        if (tab2.find(tab2_el=>tab2_el===element) && !sortie.includes(element)) {
            sortie.push(element);
        }
    });
    return sortie;
}

const elementsNonCommuns = (tab1, tab2) =>
{
    const sortie = [];
    tab1.forEach(element => {
        if (!tab2.find(tab2_el => tab2_el === element) && !sortie.includes(element)) {
                sortie.push(element);
        }
    });
    tab2.forEach(element => {
        if (!tab1.find(tab1_el=>tab1_el===element) && !sortie.includes(element)) {
                sortie.push(element);
        }
    });

    return sortie;
}

console.log('somme de tableau1 : ', sommeTableau(tableau1))
console.log('liste des 3 derniers element de tableau1 : ', derniers(tableau1, 3))
console.log('liste des 8 derniers element de tableau1 : ', derniers(tableau1, 8))
console.log('elements de tableau1  supérieur à 5: ', plusGrands(tableau1, 5))
console.log('elements noncommuns de tableau1 et tableau2 ', elementsNonCommuns(tableau1, tableau2))
console.log("------------------------------");
/* ------------------------- */


// Dates

function aujourdhui() {
        var today = new Date();
		//On recupère l'année
		var annee = today.getFullYear();
		//On recupère le numéro du mois
        //qui commence par zéro
		var mois = today.getMonth();
 
		//On recupère le numéro du jour dans la semaine
		var jour = today.getDay();
 
		//Croyez moi, c'est le numero du jour,dans le mois.
		var numeroJour = today.getDate();
 
		
    return `${tableauJours[jour]} ${numeroJour} ${tableauMois[mois]} ${annee}`
 
}

function age(jour, mois, annee)
{
    const numerMois=tableauMois.findIndex(_mois=>mois===_mois);
    const naissance = new Date(annee, numerMois, jour);
    
    if (naissance=="Invalid Date")
        return false;
    else {
        const naissance_time = naissance.getTime();
        const now = Date.now();
        if (naissance_time>=now) {
            return false;
            
        }
        return parseInt((now-naissance_time)/(1000*3600*24*364.25)) +" ans";
    }
    
}

console.log("aujourdhui :", aujourdhui())
console.log("timestamp Unix (en secondes)", Date.now() / 1000)
console.log("l'âge de Gilles né le 5 janvier 1989 :",age(5, 'janvier', 1989))
console.log("l'âge Mélodie née le 28 mars 2001: ", age(28, 'mars', 2001))
console.log("------------------------------");

// Chaines de caractères

function compterMots(chaine)
{
    return chaine.split(" ").length;

}

function inverse(chaine)
{
    return chaine.split(" ").map(mot=>mot.split("").reverse().join("")).join(" ")
}

function decale(message)
{
    return message.split(" ").map((mot) =>
    {
        var i = 0;
        var vraiMot = "";
        while (i < mot.length) {
            var index = clavier.indexOf(mot.charAt(i));
            vraiMot += index === 25?clavier[0]:clavier[index+1];
            i++;
        }
        return vraiMot;
    }).join(" ");

}

console.log("longueur de la chaine1 : ", chaine1.length)
console.log("nombre de mots de chaine1 : ", compterMots(chaine1))
console.log("Le message d'Yvan une fois décodé : ", inverse(message1));
console.log("Le message décodé : ", decale(message2));
console.log("------------------------------");